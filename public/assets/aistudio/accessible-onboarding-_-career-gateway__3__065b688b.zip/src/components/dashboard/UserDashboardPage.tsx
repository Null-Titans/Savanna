import React from 'react';
import {
  ArrowRight,
  BookOpen,
  Briefcase,
  CheckCircle2,
  Eye,
  Mic,
  ShieldCheck,
  SlidersHorizontal,
  UserCheck,
} from 'lucide-react';
import { useI18n } from '../../i18n';
import { GatewayModule } from '../../types/gateway';
import type { ColorMode } from '../../app/GatewayShell';
import type { VoiceTriggerStatus } from '../../hooks/useVoiceTrigger';
import { ReadAloudButton } from '../accessibility/ReadAloudButton';
import { useWebsiteAgent } from '../../context/WebsiteAgentContext';
import type { LearnerProfile } from '../../types/gateway';

interface UserDashboardPageProps {
  colorMode: ColorMode;
  onToggleColorMode: () => void;
  easyRead: boolean;
  onToggleEasyRead: () => void;
  autoOrientationSpeech: boolean;
  onToggleOrientationSpeech: () => void;
  voiceTriggerStatus: VoiceTriggerStatus;
  onOpenVoiceAssistant: () => void;
  onNavigate: (mod: GatewayModule) => void;
}

function getSafeLearnerOverview(liveProfile: LearnerProfile | null): {
  hasSavedProfile: boolean;
  fullName: string;
  contactMethod: string;
} {
  if (liveProfile?.fullName) {
    return {
      hasSavedProfile: true,
      fullName: liveProfile.fullName,
      contactMethod: liveProfile.contactMethod || 'Saved locally',
    };
  }
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const rawProfile =
        window.localStorage.getItem('gw_mock_learner_profile_v1') ||
        window.localStorage.getItem('gw_learner_profile');
      if (rawProfile) {
        const parsed = JSON.parse(rawProfile) as {
          fullName?: string;
          contactMethod?: string;
        };
        if (parsed?.fullName) {
          return {
            hasSavedProfile: true,
            fullName: parsed.fullName,
            contactMethod: parsed.contactMethod || 'Saved locally',
          };
        }
      }
    }
  } catch {
    // Ignore storage read errors
  }
  return {
    hasSavedProfile: false,
    fullName: 'Guest Learner (No local profile stored yet)',
    contactMethod: 'Not stored on shared devices',
  };
}

export const UserDashboardPage: React.FC<UserDashboardPageProps> = ({
  colorMode,
  onToggleColorMode,
  easyRead,
  onToggleEasyRead,
  autoOrientationSpeech,
  onToggleOrientationSpeech,
  voiceTriggerStatus,
  onOpenVoiceAssistant,
  onNavigate,
}) => {
  const { language, t } = useI18n();
  const agent = useWebsiteAgent();
  const profileSummary = getSafeLearnerOverview(agent?.savedLearnerProfile ?? null);

  return (
    <div className="space-y-8">
      <header className="rounded-2xl bg-[#0F1E36] text-white p-6 sm:p-8 shadow-lg space-y-3">
        <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
          <UserCheck className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.dashboard.domShieldBadge}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
          {t.dashboard.pageTitle}
        </h1>
        <p className="text-sm sm:text-base text-slate-200 max-w-3xl leading-relaxed">
          {t.dashboard.pageSubtitle}
        </p>
        <ReadAloudButton
          textToRead={`${t.dashboard.pageTitle}. ${t.dashboard.pageSubtitle} Profile status: ${profileSummary.fullName}.`}
        />
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Card 1: Profile Status */}
        <section
          aria-labelledby="dash-profile-heading"
          className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs space-y-4"
        >
          <h2
            id="dash-profile-heading"
            className="text-lg font-bold text-[#0F1E36] dark:text-white flex items-center gap-2"
          >
            <UserCheck className="w-5 h-5 text-[#1E3A5F] dark:text-amber-400" aria-hidden="true" />
            <span>{t.dashboard.statusHeading}</span>
          </h2>
          <dl className="space-y-2 text-sm">
            <div>
              <dt className="text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                Learner
              </dt>
              <dd className="font-semibold text-[#0F1E36] dark:text-slate-100">
                {profileSummary.fullName}
              </dd>
            </div>
            <div>
              <dt className="text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                Contact Route
              </dt>
              <dd className="text-slate-700 dark:text-slate-300">
                {profileSummary.contactMethod}
              </dd>
            </div>
          </dl>
          <div className="pt-2 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => onNavigate(profileSummary.hasSavedProfile ? 'profile' : 'onboarding')}
              className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 rounded-lg bg-[#0F1E36] hover:bg-[#1E3A5F] text-white text-sm font-semibold cursor-pointer"
            >
              <span>{profileSummary.hasSavedProfile ? t.nav.profile : t.nav.startAction}</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </section>

        {/* Card 2: Accessibility Controls */}
        <section
          aria-labelledby="dash-prefs-heading"
          className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs space-y-4"
        >
          <h2
            id="dash-prefs-heading"
            className="text-lg font-bold text-[#0F1E36] dark:text-white flex items-center gap-2"
          >
            <SlidersHorizontal
              className="w-5 h-5 text-[#1E3A5F] dark:text-amber-400"
              aria-hidden="true"
            />
            <span>{t.dashboard.preferencesHeading}</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300">
            Active language: <strong>{language.toUpperCase()}</strong> · Hands-free mic:{' '}
            <strong>{voiceTriggerStatus}</strong>
          </p>
          <div className="flex flex-col gap-2">
            <button
              type="button"
              onClick={onToggleColorMode}
              aria-pressed={colorMode === 'dark'}
              className="min-h-[44px] px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-start text-sm font-semibold text-[#0F1E36] dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer flex items-center justify-between"
            >
              <span className="inline-flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#1E3A5F] dark:text-amber-400" aria-hidden="true" />
                <span>{colorMode === 'dark' ? t.common.lightModeLabel : t.common.darkModeLabel}</span>
              </span>
              <span className="text-xs font-bold uppercase">{colorMode}</span>
            </button>
            <button
              type="button"
              onClick={onToggleEasyRead}
              aria-pressed={easyRead}
              className="min-h-[44px] px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-start text-sm font-semibold text-[#0F1E36] dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer flex items-center justify-between"
            >
              <span className="inline-flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-[#1E3A5F] dark:text-amber-400" aria-hidden="true" />
                <span>{easyRead ? t.common.easyReadOn : t.common.easyReadOff}</span>
              </span>
              <span className="text-xs font-bold uppercase">{easyRead ? 'ON' : 'OFF'}</span>
            </button>
            <button
              type="button"
              onClick={onToggleOrientationSpeech}
              aria-pressed={autoOrientationSpeech}
              className="min-h-[44px] px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-start text-sm font-semibold text-[#0F1E36] dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer flex items-center justify-between"
            >
              <span>{autoOrientationSpeech ? t.orientation.autoSpeechOn : t.orientation.autoSpeechOff}</span>
              <span className="text-xs font-bold uppercase">{autoOrientationSpeech ? 'ON' : 'OFF'}</span>
            </button>
          </div>
        </section>

        {/* Card 3: Security & Privacy Guardrails */}
        <section
          aria-labelledby="dash-security-heading"
          className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs space-y-4"
        >
          <h2
            id="dash-security-heading"
            className="text-lg font-bold text-[#0F1E36] dark:text-white flex items-center gap-2"
          >
            <ShieldCheck className="w-5 h-5 text-emerald-700 dark:text-emerald-400" aria-hidden="true" />
            <span>{t.dashboard.securityHeading}</span>
          </h2>
          <ul className="space-y-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
              <span>Passwords, PINs, tokens, and financial details are blocked from chat and scrubbed on DOM context reads.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
              <span>Google AI Studio API calls run strictly through server-side Express proxies (`GEMINI_API_KEY`).</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
              <span>Voice recordings are transcribed transiently and never persisted.</span>
            </li>
          </ul>
          <button
            type="button"
            onClick={onOpenVoiceAssistant}
            className="inline-flex items-center gap-2 min-h-[44px] px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-[#0F1E36] text-sm font-bold cursor-pointer"
          >
            <Mic className="w-4 h-4" aria-hidden="true" />
            <span>{t.footer.openAssistantBtn}</span>
          </button>
        </section>
      </div>

      {/* Quick Jump Directory */}
      <section
        aria-labelledby="dash-jumps-heading"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs space-y-4"
      >
        <h2 id="dash-jumps-heading" className="text-lg font-bold text-[#0F1E36] dark:text-white">
          {t.dashboard.quickLinksHeading}
        </h2>
        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => onNavigate('career')}
            className="inline-flex items-center gap-2 min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-semibold text-[#0F1E36] dark:text-slate-100 hover:bg-amber-50 dark:hover:bg-slate-700 cursor-pointer"
          >
            <Briefcase className="w-4 h-4 text-[#1E3A5F] dark:text-amber-400" aria-hidden="true" />
            <span>{t.nav.careers}</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('learning')}
            className="inline-flex items-center gap-2 min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-semibold text-[#0F1E36] dark:text-slate-100 hover:bg-amber-50 dark:hover:bg-slate-700 cursor-pointer"
          >
            <BookOpen className="w-4 h-4 text-[#1E3A5F] dark:text-amber-400" aria-hidden="true" />
            <span>{t.nav.learning}</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('employer')}
            className="inline-flex items-center gap-2 min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-semibold text-[#0F1E36] dark:text-slate-100 hover:bg-amber-50 dark:hover:bg-slate-700 cursor-pointer"
          >
            <span>{t.nav.employers}</span>
          </button>
        </div>
      </section>
    </div>
  );
};
