import React, { useCallback, useEffect, useState } from 'react';
import { Compass, Volume2, VolumeX } from 'lucide-react';
import { useI18n } from '../../i18n';
import { GatewayModule, SupportedLanguage } from '../../types/gateway';
import {
  buildFullOrientationText,
  getOrientationSpec,
} from '../../utils/pageOrientation';
import { findNativeBrowserVoice } from '../../services/speech/speechService';

interface PageOrientationAnnouncerProps {
  activeModule: GatewayModule;
  onAskWhereAmI?: () => void;
  onAskWhatCanIDo?: () => void;
  autoSpeechEnabled: boolean;
  onToggleAutoSpeech: () => void;
}

function speakNativeOrientationIfSupported(
  text: string,
  language: SupportedLanguage
): void {
  if (
    typeof window === 'undefined' ||
    !window.speechSynthesis ||
    typeof window.SpeechSynthesisUtterance === 'undefined'
  ) {
    return;
  }

  // Strictly match an authentic browser voice for the active language;
  // never force an English voice to read Amharic or Afaan Oromo.
  const nativeVoice = findNativeBrowserVoice(language);
  if (!nativeVoice) return;

  try {
    window.speechSynthesis.cancel();
    const utterance = new window.SpeechSynthesisUtterance(text);
    utterance.voice = nativeVoice;
    utterance.lang = nativeVoice.lang;
    utterance.rate = 0.98;
    window.speechSynthesis.speak(utterance);
  } catch {
    // Ignore speech synthesis errors on restricted headless/browser runtimes
  }
}

export const PageOrientationAnnouncer: React.FC<PageOrientationAnnouncerProps> = ({
  activeModule,
  onAskWhereAmI,
  onAskWhatCanIDo,
  autoSpeechEnabled,
  onToggleAutoSpeech,
}) => {
  const { language, t } = useI18n();
  const [announcement, setAnnouncement] = useState<string>(() =>
    buildFullOrientationText(activeModule, language)
  );

  const spec = getOrientationSpec(activeModule, language);

  const announceNow = useCallback(() => {
    const text = buildFullOrientationText(activeModule, language);
    setAnnouncement(text);
    speakNativeOrientationIfSupported(text, language);
  }, [activeModule, language]);

  // Update visual/screen-reader status text silently on route change without unsolicited auto-speech.
  // Speech synthesis runs ONLY when user explicitly requests orientation ("Where am I?" / Alt+Shift+L).
  useEffect(() => {
    const text = buildFullOrientationText(activeModule, language);
    setAnnouncement(text);
  }, [activeModule, language]);

  // Global shortcut: Alt+Shift+L speaks and updates exact spatial orientation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && e.shiftKey && e.key.toLowerCase() === 'l') {
        e.preventDefault();
        announceNow();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [announceNow]);

  return (
    <section
      aria-label="Page orientation and spatial guide"
      className="mb-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-3"
    >
      <div className="flex items-start gap-2.5 min-w-0">
        <Compass
          className="w-5 h-5 text-[#1E3A5F] dark:text-amber-400 shrink-0 mt-0.5"
          aria-hidden="true"
        />
        <div className="space-y-0.5 min-w-0">
          <p className="text-xs sm:text-sm font-bold text-[#0F1E36] dark:text-white">
            {spec.title}
          </p>
          <p
            role="status"
            aria-live="polite"
            aria-atomic="true"
            className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-snug"
          >
            {announcement}
          </p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={() => {
            announceNow();
            onAskWhereAmI?.();
          }}
          aria-label={t.orientation.announceNowAria}
          className="inline-flex items-center gap-1.5 min-h-[44px] px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-[#0F1E36] dark:text-slate-100 hover:bg-amber-50 dark:hover:bg-slate-700 cursor-pointer"
        >
          <Compass className="w-3.5 h-3.5 text-[#1E3A5F] dark:text-amber-400" aria-hidden="true" />
          <span>{t.orientation.whereAmIButton}</span>
        </button>

        {onAskWhatCanIDo && (
          <button
            type="button"
            onClick={onAskWhatCanIDo}
            className="inline-flex items-center gap-1.5 min-h-[44px] px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-[#0F1E36] dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer"
          >
            <span>{t.orientation.whatCanIDoButton}</span>
          </button>
        )}

        <button
          type="button"
          onClick={onToggleAutoSpeech}
          aria-pressed={autoSpeechEnabled}
          className={`inline-flex items-center gap-1.5 min-h-[44px] px-3 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer transition-colors ${
            autoSpeechEnabled
              ? 'border-[#0F1E36] bg-[#0F1E36] text-white dark:border-amber-400 dark:bg-amber-500 dark:text-[#0F1E36]'
              : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-[#0F1E36] dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-700'
          }`}
        >
          {autoSpeechEnabled ? (
            <Volume2 className="w-3.5 h-3.5" aria-hidden="true" />
          ) : (
            <VolumeX className="w-3.5 h-3.5" aria-hidden="true" />
          )}
          <span>
            {autoSpeechEnabled ? t.orientation.autoSpeechOn : t.orientation.autoSpeechOff}
          </span>
        </button>
      </div>
    </section>
  );
};
